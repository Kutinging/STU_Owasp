<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>OWASP_LAB2</title>
</head>
<body>

<form name="form1" action="login.php" method="post">
<p> 帳號: <input type="text" name="login_id"> </p>
<p> 密碼: <input type="password" name="login_pwd"> </p>
<p> <input type="submit" name="submit" value="登入"> </p>
</form>

</body>
</html>
