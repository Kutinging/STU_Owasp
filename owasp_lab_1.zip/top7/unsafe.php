<?php header("Content-Type:text/html; charset=utf-8");?>
<h1 style="color: red;">警告!你正在瀏覽不正常網頁</h1>
