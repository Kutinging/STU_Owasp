<?php
session_start();
include('conn.php');
// 修改編號
$no = $_GET['no'];
// 撈出對應編號的資料
$sql = 'Select * From messages Where tno=?';
$sql_array = array($no);
$sth = $conn -> prepare($sql);
$sth -> execute($sql_array);
if($sth -> errorCode() == '00000'){
    $rs = $sth -> fetchAll();
}
print_r("<pre>");
print_r($rs);
print_r("</pre>");
/*$sql = "Select * From messages Where tno='".$no."'";
$rs = mysql_query($sql) or die(mysql_error());
$row = mysql_fetch_array($rs);*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
<form action="addmsg.php" method="post">
<h1>您現在的身分是 <span style="color:red;"><?php print($_SESSION['login']);?></span></h1>
<h1>編輯留言：</h1>
<p><input type="hidden" name="tno" value="<?php print($rs[0]['tno']);?>"></p>
<p><input type="text" name="account" value="<?php print($rs[0]['account']);?>"></p>
<p><textarea name="content" id="content" cols="30" rows="10"><?php print($rs[0]['content']);?></textarea></p>
<p> <input type="submit" name="submit" value="確定"> </p>
</form>

</body>
</html>
