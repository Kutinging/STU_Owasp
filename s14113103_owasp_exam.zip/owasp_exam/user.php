<?php
session_start();
include('conn.php');

// 檢查登入狀況，沒登入就轉到首頁
if( $_SESSION['login'] == '' ){
    header( 'Location: ./index.php?url='.$_SERVER['PHP_SELF'] );
}

$sql = 'Select * From messages order by modtime DESC';
$sql_array = array($_SESSION['login']);
$sth = $conn -> prepare($sql);
$sth -> execute($sql_array);
$rs = $sth -> fetchAll();

/*$sql = 'Select * From messages order by modtime DESC';
$rs = mysql_query($sql) or die(mysql_error());*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
<form action="addmsg.php" method="post">
<h1>您現在的身分是 <span style="color:red;"><?php print($_SESSION['login']);?></span></h1>
<h1>請在下面留言並送出：</h1>
<p><textarea name="content" id="content" cols="30" rows="10"><?php print(htmlentities(@$content));?></textarea></p>
<p> <input type="submit" name="submit" value="確定"> </p>
</form>
<div>
<?php
//while($row = mysql_fetch_array($rs)){
$rowCount = count($rs);
for($i=0;$i<$rowCount;$i++){
?>
    <table border="1" width="400">
        <tr><td width="100">編號：</td><td><?php print($rs[$i]['tno']);?></td></tr>
        <tr><td>留言時間：</td><td><?php print($rs[$i]['modtime']);?></td></tr>
        <tr><td>留言人：</td><td><?php print($rs[$i]['account']);?></td></tr>
        <tr><td>內容：</td><td><?php print(nl2br(htmlentities($rs[$i]['content'])));?></td></tr>
    </table>
</div>
<br />
<?php
}
?>

</body>
</html>
