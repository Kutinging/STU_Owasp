<?php
session_start();
include('conn.php');

if( $_POST['content'] != '' ){
    if( @$_POST['tno'] == '' ){
        $account = $_SESSION['login'];
        $content = $_POST['content'];
        $modtime = date('Y/m/d H:i:s');
		$sql = 'Insert Into messages values(null,?,?,?)';
        $sql_array = array($account, $content,$modtime);
        $sth = $conn -> prepare($sql);
        $sth -> execute($sql_array);
        if($sth -> errorCode() == '00000'){
            print('<h1>新增成功!</h1>');
        }else{
            print('<h1>新增失敗!</h1>');
        }
        /*$sql = "Insert Into messages Values(null,'".$account."','".$content."','".$modtime."')";
        $rs = mysql_query($sql) or die(mysql_error());
        print('<h1>新增成功!</h1>');*/
    }else{
        $tno = $_POST['tno'];
        $account = $_POST['account'];
        $content = $_POST['content'];
        $modtime = date('Y/m/d H:i:s');
		$sql = 'Update messages Set account= ? ,content= ? ,modtime = ? Where tno= ?';
        $sql_array = array($account,$content, $modtime,$tno);
        $sth = $conn -> prepare($sql);
        $sth -> execute($sql_array);
        if($sth -> errorCode() == '00000'){
            print('<h1>修改成功!</h1>');
        }else{
            print('<h1>修改失敗!</h1>');
        }
        /*$sql = "Update messages Set account='".$account."',content='".$content."',modtime='".$modtime."' Where tno='".$tno."'";
        $rs = mysql_query($sql) or die(mysql_error());
        print('<h1>修改成功!</h1>');*/
    }
    if($_SESSION['login'] == 'user'){
        print('<h1><a href="./user.php">回列表</a></h1>');
    }else{
        print('<h1><a href="./admin.php">回列表</a></h1>');
    }
    print('<h1><a href="./">回登入頁面</a></h1>');
}else{
    $url = './';
    header( 'Location: '.$url );
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
</body>
</html>
