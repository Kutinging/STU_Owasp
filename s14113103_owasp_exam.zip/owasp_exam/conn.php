<?php
/*$conn = mysql_connect('127.0.0.1', 'account', 'password') or die('Error with MySQL connection');
mysql_query("SET NAMES 'utf8'");
mysql_select_db('test');*/
$dsn = "mysql:host=localhost;dbname=test";
$conn = new PDO($dsn, "account", "password", array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));


//$conn2 = new PDO('mysql:host=127.0.0.1;dbname=test', 'account', 'password');

date_default_timezone_set("Asia/Taipei");
?>
