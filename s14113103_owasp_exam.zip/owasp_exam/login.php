<?php
session_start();
include('conn.php');
$url = './';
if( $_POST['login_id'] != '' && $_POST['login_pwd'] != '' ){
    $account = $_POST['login_id'];
    $password = $_POST['login_pwd'];
	
    $sql = 'Select * From member Where account=? And password=?';
    $sql_array = array($_POST['login_id'], sha1($_POST['login_pwd']));
    $sth = $conn -> prepare($sql);
    $sth -> execute($sql_array);
    if($sth -> errorCode() == '00000'){
        $rs = $sth -> fetchAll();
    }
    if( $sth->rowCount() == 1 ){
        $_SESSION['login'] = $_POST['login_id'];
        // 如果沒有登入前頁面就各自轉到權限頁面，否則轉到登入前頁面
        if( $_GET['url'] == '' ){
            if($_POST['login_id'] == 'admin'){
                $url = 'admin.php';
            }else {
                $url = 'user.php';
            }
        }else{
            $url = $_GET['url'];
        }
    }
}else{
    $url = './';
}
header( 'Location: '.$url );
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
</body>
</html>
