<?php header("Content-Type:text/html; charset=utf-8");?>
<h1>這是正常安全網頁</h1>
